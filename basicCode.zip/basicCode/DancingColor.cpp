// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Include GLEW
#include <GL/glew.h>

// Include GLFW
#include <glfw3.h>
GLFWwindow* window1;

// Include GLM
#include <glm/glm.hpp>
using namespace glm;

int main(void)
{
	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	window1 = glfwCreateWindow(800, 600, "Dancing color", NULL, NULL);
	if (window1 == NULL){
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window1);
	glfwSwapInterval(1);

	// Initialize GLEW
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		return -1;
	}

	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(window1, GLFW_STICKY_KEYS, GL_TRUE);

	int counter = 0;
	int speed = 100;
	glm::vec3 color1;
	glm::vec3 color2;
	glm::vec3 color;
	float weight = 0;
	 
	// initial color, we will keep blending two randomly selected colors
	srand(time(NULL));
	color1 = glm::vec3((float)rand() / RAND_MAX, (float)rand() / RAND_MAX, (float)rand() / RAND_MAX);
	color2 = glm::vec3((float)rand() / RAND_MAX, (float)rand() / RAND_MAX, (float)rand() / RAND_MAX);

	do{
		// get input
		glfwPollEvents();
		counter++;
		
		// compute blending color
		weight = (float)(counter % speed) / speed;
		color = glm::mix(color1, color2, weight);

		// now, it's time to random a new color
		if (weight > 0.99){
			color1 = color2;
			color2 = glm::vec3((float)rand() / RAND_MAX, (float)rand() / RAND_MAX, (float)rand() / RAND_MAX);
			counter = 0;
		}

		// Changing background
		glClearColor(color.r, color.g,color.b, 0.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		

		// Swap buffers
		glfwSwapBuffers(window1);

	} // Check if the ESC key was pressed or the window was closed
	while (glfwGetKey(window1, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
	glfwWindowShouldClose(window1) == 0);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;
}

